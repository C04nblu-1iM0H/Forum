<?php
$db = mysqli_connect('localhost', 'root', '', 'registr') or die("Database Error");
?>